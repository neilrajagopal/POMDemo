package constDemo;

public class DemoClass {
	int i=10;
	public DemoClass(int i)
	{
		this.i=i;
		System.out.println(this.i);
		
	}

	
	public void demoFun()
	{
		System.out.println("Demo Non Static");
	}
}
