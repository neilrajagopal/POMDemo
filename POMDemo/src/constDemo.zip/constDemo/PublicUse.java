package constDemo;

public class PublicUse {

	public static void main(String[] args) {
		
		DemoClass d = new DemoClass(5);
		
		//d.demoFun();
	}

}
